/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Event;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import tools.MaConnexion;

/**
 *
 * @author Espace Sboui
 */
public class SEvent implements Iservice<Event>{
     Connection cnx=MaConnexion.getInstance().getCnx();
     @Override
    public void ajouter(Event e) {
        String sql ="insert into evenement(nom,lieu,date,nbparticipation,description,prix) values(?,?,?,?,?,?) ";
        try {
            PreparedStatement ste =cnx.prepareStatement(sql);
            ste.setString(1, e.getNom());
            ste.setString(2, e.getLieu());
            ste.setDate(3, e.getDate());
            ste.setInt(4, e.getNbparticipation());
            ste.setString(5, e.getDescription());
            ste.setFloat(6, e.getPrix());
            ste.executeUpdate();
            System.out.println("evenement ajouté");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public List<Event> afficher() {
        List<Event> ev = new ArrayList<>();
        String sql ="select * from evenement";
        try {
            Statement ste= cnx.createStatement();
            ResultSet rs =ste.executeQuery(sql);
            while(rs.next()){
                Event e = new Event();
                e.setId(rs.getInt("id"));
                e.setNom(rs.getString("nom"));
                e.setLieu(rs.getString("lieu"));
                e.setDate(rs.getDate("date"));
                e.setNbparticipation(rs.getInt("nbparticipation"));
                e.setDescription(rs.getString("description"));
                e.setPrix(rs.getFloat("prix"));
                ev.add(e);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return ev;
    }

    
    /*public void supprimer(Event e) {
        String requete = "DELETE FROM evenement WHERE id=?";
        try {
            
            PreparedStatement pst = MaConnexion.getInstance().getCnx().prepareStatement(requete);
            pst.setInt(1,e.getId());
            pst.executeUpdate();
            System.out.println("event supprimé");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        
    }
    
    }*/
    public void supprimer(int t) throws SQLException {
        
         
         String req="DELETE FROM evenement WHERE id="+t+";";
   
        Statement st=cnx.createStatement();
        st.executeUpdate(req);
        
    }

/*public void update(Event e) {
        
    String sql="update evenement set  nom=?, lieu= ?, date=?, nbparticipation=?, description=? , prix=? where id='"+e.getId()+"'";
            try {
            PreparedStatement ste =cnx.prepareStatement(sql);
            ste.setString(1, e.getNom());
            ste.setString(2, e.getLieu());
            ste.setDate(3, e.getDate());
            ste.setInt(4, e.getNbparticipation());
            ste.setString(5, e.getDescription());
            ste.setFloat(6, e.getPrix());
            
           ste.executeUpdate();
            System.out.println("Evenement Modifié");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    
}*/
    public void modifier(Event e) throws SQLException{

        String req="UPDATE evenement SET `nom`='"+e.getNom()+"',`lieu`='"+e.getLieu()+"',`date`='"+e.getDate()+"',`Nbparticipation`='"+e.getNbparticipation()+"',`description`='"+e.getDescription()+"',`prix`='"+e.getPrix()+"' WHERE `id`='"+e.getId()+"';";
        Statement st=cnx.createStatement();
        st.executeUpdate(req);
    }
    
}
