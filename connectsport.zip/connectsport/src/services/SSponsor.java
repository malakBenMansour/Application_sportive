/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;


import entities.Sponsor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import tools.MaConnexion;

/**
 *
 * @author Espace Sboui
 */
public class SSponsor implements Iservice<Sponsor> {
    Connection cnx=MaConnexion.getInstance().getCnx();
     @Override
    public void ajouter(Sponsor s) {
        String sql ="insert into sponsor(nom,prenom,datenaissance,adresse,tel,mail) values(?,?,?,?,?,?) ";
        try {
            PreparedStatement ste =cnx.prepareStatement(sql);
            ste.setString(1, s.getNom());
            ste.setString(2, s.getPrenom());
            ste.setDate(3, s.getDatenaissance());
            ste.setString(4, s.getAdresse());
            ste.setInt(5, s.getTel());
            ste.setString(6, s.getMail());
            ste.executeUpdate();
            System.out.println("sponsor ajouté");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public List<Sponsor> afficher() {
        List<Sponsor> sp = new ArrayList<>();
        String sql ="select * from sponsor";
        try {
            Statement ste= cnx.createStatement();
            ResultSet rs =ste.executeQuery(sql);
            while(rs.next()){
                Sponsor e = new Sponsor();
                e.setId(rs.getInt("id"));
                e.setNom(rs.getString("nom"));
                e.setPrenom(rs.getString("prenom"));
                e.setDatenaissance(rs.getDate("datenaissance"));
                e.setAdresse(rs.getString("adresse"));
                e.setTel(rs.getInt("tel"));
                e.setMail(rs.getString("mail"));
                sp.add(e);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return sp;
    }

    
    /*public void supprimer(Sponsor s) {
        String requete = "DELETE FROM sponsor WHERE id=?";
        try {
            
            PreparedStatement pst = MaConnexion.getInstance().getCnx().prepareStatement(requete);
            pst.setInt(1,s.getId());
            pst.executeUpdate();
            System.out.println("sponsor supprimé");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        
    }
    
    }*/
    public void supprimer(int t) throws SQLException {
        
         
         String req="DELETE FROM sponsor WHERE id="+t+";";
   
        Statement st=cnx.createStatement();
        st.executeUpdate(req);
        
    }
    /*public void update(Sponsor s) {
        
    String sql="update sponsor set  nom=?, prenom= ?, datenaissance=?, adresse=?, tel=? , mail=? where id='"+s.getId()+"'";
            try {
            PreparedStatement ste =cnx.prepareStatement(sql);
            ste.setString(1, s.getNom());
            ste.setString(2, s.getPrenom());
            ste.setDate(3, s.getDatenaissance());
            ste.setString(4, s.getAdresse());
            ste.setInt(5, s.getTel());
            ste.setString(6, s.getMail());
            
           ste.executeUpdate();
            System.out.println("sponsor Modifié");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    
}*/
    public void modifier(Sponsor s) throws SQLException{

        String req="UPDATE sponsor SET `nom`='"+s.getNom()+"',`prenom`='"+s.getPrenom()+"',`datenaissance`='"+s.getDatenaissance()+"',`adresse`='"+s.getAdresse()+"',`tel`='"+s.getTel()+"',`mail`='"+s.getMail()+"' WHERE `id`='"+s.getId()+"';";
        Statement st=cnx.createStatement();
        st.executeUpdate(req);
    }


}
